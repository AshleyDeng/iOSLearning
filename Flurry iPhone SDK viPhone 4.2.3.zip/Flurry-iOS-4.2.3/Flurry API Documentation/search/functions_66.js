var searchData=
[
  ['fetchadforspace_3aframe_3asize_3a',['fetchAdForSpace:frame:size:',['../interface_flurry_ads.html#a19a2ae3e9fd85ad0e21c13f5abdc0079',1,'FlurryAds']]],
  ['fetchanddisplayadforspace_3aview_3asize_3a',['fetchAndDisplayAdForSpace:view:size:',['../interface_flurry_ads.html#aabef9360d7bc25ff7b6d32d700451a4b',1,'FlurryAds']]]
];
