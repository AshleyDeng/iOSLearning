var searchData=
[
  ['displayadforspace_3amodallyforviewcontroller_3a',['displayAdForSpace:modallyForViewController:',['../interface_flurry_ads.html#a6926081a057d41fe81c2476a0dcc1062',1,'FlurryAds']]],
  ['displayadforspace_3aonview_3a',['displayAdForSpace:onView:',['../interface_flurry_ads.html#a548bad4390b575c117754c915cc4077a',1,'FlurryAds']]]
];
