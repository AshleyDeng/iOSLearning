var searchData=
[
  ['initialize_3a',['initialize:',['../interface_flurry_ads.html#a35a71c7b8775be1c95aefc4b1e6e236b',1,'FlurryAds']]],
  ['isadavailableforspace_3aview_3asize_3atimeout_3a',['isAdAvailableForSpace:view:size:timeout:',['../interface_flurry_ads.html#a5bfd663d6da1404c30c6774bd581e225',1,'FlurryAds']]]
];
